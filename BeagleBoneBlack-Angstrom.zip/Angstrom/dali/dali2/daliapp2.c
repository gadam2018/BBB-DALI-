#include <stdio.h>
#include <fcntl.h>
#include <stdint.h>
#include <time.h>
 
int main(void)
{
  int fd, answer;
  char gpio_buffer[10];
  uint8_t choice[2];

  fd = open( "/dev/dalidrv2", O_RDWR );

  printf( "Value of fd is: %d", fd );

  if( fd < 0 )
  {
    printf("Cannot open device \t");
    printf(" fd = %d \n",fd);
    return 0;
  }


/* //ARDUINO example 
choice[0]=255; choice[1]=32; write( fd, choice, 1 ); //broadcast RESET
choice[0]=255; choice[1]=32; write( fd, choice, 1 ); //broadcast RESET 
read( fd, gpio_buffer, 1);
printf("\nGPIO value is: %s \n", gpio_buffer );
  
choice[0]=165; choice[1]=0; write( fd, choice, 1 ); //INITIALISE
choice[0]=165; choice[1]=0; write( fd, choice, 1 ); //INITIALISE
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );

choice[0]=183; choice[1]=1; write( fd, choice, 1 ); //PROGRAM SHORT ADDRESS
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );

choice[0]=161; choice[1]=0; write( fd, choice, 1 ); //TERMINATE (?)
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );
*/

/* // ONLY 1 BALLAST method
choice[0]=163; choice[1]=1; write( fd, choice, 1 ); //DTR
read( fd, gpio_buffer, 1);
printf("\nGPIO value is: %s \n", gpio_buffer );

choice[0]=1; choice[1]=152; write( fd, choice, 1 ); //QUERY content of DTR
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );

choice[0]=1; choice[1]=128; write( fd, choice, 1 ); //STORE DTR AS SHORT ADDRRESS
choice[0]=1; choice[1]=128; write( fd, choice, 1 ); //STORE DTR AS SHORT ADDRRESS
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );
*/


/*// PHYSICAL ALLOCATION METHOD
choice[0]=165; choice[1]=0; write( fd, choice, 1 ); //INITIALISE
choice[0]=165; choice[1]=0; write( fd, choice, 1 ); //INITIALISE
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );

choice[0]=189; choice[1]=0; write( fd, choice, 1 ); //PHYSICAL SELECTION
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );

//disconnect the lamp
//after disconnection wait 5s to sense it within 10s
printf("\n Counting 8 secs - disconnect and connect\n"); sleep(8); 
//connect

choice[0]=187; choice[1]=0; write( fd, choice, 1 ); //QUERY SHORT ADDRESS
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );

choice[0]=183; choice[1]=1; write( fd, choice, 1 ); //PROGRAM SHORT ADDRESS
read( fd, gpio_buffer, 1);
printf("GPIO value is: %s \n", gpio_buffer );
*/


/*
 answer=0;
 do
 {
  choice[0]=254; choice[1]=160; write( fd, choice, 1 ); //broadcast direct arc level 
  choice[0]=254; choice[1]=144; write( fd, choice, 1 ); 
  choice[0]=254; choice[1]=0; write( fd, choice, 1 );
  choice[0]=255; choice[1]=0; write( fd, choice, 1 );//broadcast command OFF (indirect)
  choice[0]=0; choice[1]=0; write( fd, choice, 1 ); //short address direct arc level
  choice[0]=0; choice[1]=144; write( fd, choice, 1 ); //short address direct arc level
  choice[0]=1; choice[1]=0; write( fd, choice, 1 );  //short address follows command OFF (indirect)
  choice[0]=126; choice[1]=144; write( fd, choice, 1 ); //short address direct arc level
  choice[0]=127; choice[1]=0; write( fd, choice, 1 );  //short address follows command OFF (indirect)
  printf("\n continue? press any number but not 0");
  scanf( "%d", &answer); 
 } while (answer!=0);
 */
  
 choice[0]=0;
  printf("\nPlease enter address byte: \t");
  scanf( "%d", &choice[0] );
 while (choice[0]!=199)
 {
  printf("Your choice is: %d \n", choice[0] );
  printf("\nPlease enter data byte: \t");
  scanf( "%d", &choice[1] );
  printf("Your data byte is: %d \n", choice[1] );
  write( fd, choice, 1 ); 

  //read( fd, gpio_buffer, 1);
  //printf("GPIO value is: %s \n", gpio_buffer ); 
  
  printf("\nPlease enter address byte: \t");
  scanf( "%d", &choice[0] );
  }
  
  
  if( 0 != close(fd) )
  {
    printf("Could not close device\n");
  }

  return 0;
}
