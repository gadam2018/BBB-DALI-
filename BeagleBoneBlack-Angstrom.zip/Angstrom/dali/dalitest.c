#include <stdio.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/sched.h>
#include <string.h>

#define DALI_STOPBIT_VAL    3
 
typedef struct manchesterBitValList_t {
  struct manchesterBitValList_t *pNext;
  uint8_t bitVal;
}manchesterBitValList_t;

static manchesterBitValList_t* pBitValRoot = NULL; 

static void dali_manchesterListAddVal(uint8_t val)
{
  manchesterBitValList_t* pTemp = malloc(sizeof(manchesterBitValList_t));
  pTemp->pNext = malloc(sizeof(manchesterBitValList_t));
  pTemp->pNext->pNext = NULL;
  switch(val)
    {
      case 0:
        printf("Case 0\n");
        pTemp->bitVal = 0;
        pTemp->pNext->bitVal = 1;
        break;

      case DALI_STOPBIT_VAL:
        printf("Case DALI_STOPBIT_VAL\n");
        pTemp->bitVal = 1;
        pTemp->pNext->bitVal = 1;
        break;

      default: //if it's bigger than 0, it's a one
        printf("Case Default 1 \n");
        pTemp->bitVal = 1;
        pTemp->pNext->bitVal = 0;
      break;
    }

  if(pBitValRoot != NULL){
    pTemp->pNext->pNext = pBitValRoot;
    printf("pBitValRoot = NULL\n");
  }
  pBitValRoot = pTemp;     
  printf("Bit val %x \n", pBitValRoot->bitVal);

}

static void dali_manchesterListAddByte(uint8_t byte)
{
  int i = 0,r,byte2;
   printf("byte is %d and in hex is %x\n",byte, byte);
  for(i = 0; i < 8; i++)
  { 
	  byte2=(0x1 << i);
	  r= byte & byte2;
	  printf(" i= %d  byte = %d byte2= %d  r=%d\n",i, byte, byte2, r);
    //printf(" i=%d byte = %d\n",i,byte & (0x1 << i)); 
    //dali_manchesterListAddVal(byte & (0x1 << i));
  }
}


static ssize_t dali_write(const uint8_t *writeBuff, size_t count)
{
 	//char writeBuff[2];

    /* writeBuff[0]=buff[0];
    writeBuff[1]=buff[1];
    strcp(writeBuff, buff);
    size_t i;

               for (i = 0; i < 2 && buff[i] != '\0'; i++)
                   writeBuff[i] = buff[i];
               for ( ; i < 2; i++)
                   writeBuff[i] = '\0';*/

	printf( "Executing WRITE.\n");
	  printf("The amount of bytes of memory we get is %zu\n",sizeof(writeBuff));
	//dali_manchesterListAddVal(DALI_STOPBIT_VAL);
	//dali_manchesterListAddVal(DALI_STOPBIT_VAL);
	
	//printf("writeBuff = %s \n", writeBuff);
	printf("writeBuff[1] = %d \n", writeBuff[1]);
	printf("writeBuff[0] = %d \n", writeBuff[0]);
	
	//dali_manchesterListAddByte(255);
	
	dali_manchesterListAddByte(writeBuff[1]);
	dali_manchesterListAddByte(writeBuff[0]);
	
	//dali_manchesterListAddVal(1);

  	return 2;
}
/*
 static void dali_manchesterListAddByte(char byte)
{
  int i = 0,r,byte2;
   printf("byte is %c in dec ascii is %d and in hex is %x\n",byte,byte, byte);
  for(i = 0; i < 8; i++)
  { 
	  byte2=(0x1 << i);
	  r= byte & byte2;
	  printf(" i= %d  byte = %d byte2= %d  r=%d\n",i, byte, byte2, r);
    //printf(" i=%d byte = %d\n",i,byte & (0x1 << i)); 
    //dali_manchesterListAddVal(byte & (0x1 << i));
  }
}

 
static ssize_t dali_write(const char *writeBuff, size_t count)
{
 	//char writeBuff[2];

    /* writeBuff[0]=buff[0];
    writeBuff[1]=buff[1];
    strcp(writeBuff, buff);
    size_t i;

               for (i = 0; i < 2 && buff[i] != '\0'; i++)
                   writeBuff[i] = buff[i];
               for ( ; i < 2; i++)
                   writeBuff[i] = '\0';*/
/*
	printf( "Executing WRITE.\n");
	  printf("The amount of bytes of memory we get is %zu\n",sizeof(writeBuff));
	//dali_manchesterListAddVal(DALI_STOPBIT_VAL);
	//dali_manchesterListAddVal(DALI_STOPBIT_VAL);
	
	printf("writeBuff = %s \n", writeBuff);
	printf("writeBuff[1] = %c \n", writeBuff[1]);
	printf("writeBuff[0] = %c \n", writeBuff[0]);
	
	dali_manchesterListAddByte(255);
	
	//dali_manchesterListAddByte(writeBuff[1]);
	//dali_manchesterListAddByte(writeBuff[0]);
	
	//dali_manchesterListAddVal(1);

  	return 2;
}

*/

int main(void)
{
  //char choice[10];
  uint8_t choice[10];
  //int choice[10];
  
   printf("\nPlease give address byte: \t");  
   //scanf( "%s", choice );
   scanf( "%d", &choice[0] );
   //printf("Your choice is: %s \n", choice );   
   printf("Your address byte is: %d \n", choice[0] ); 
   printf("\nPlease enter data byte: \t");  
   scanf( "%d", &choice[1] );
   printf("Your data byte is: %d \n", choice[1] ); 
   dali_write(choice, 1 );
  
 // int temp = 100;
	 
//	printf("\n temp is = %1d\n" , temp );
  return 0;
}
