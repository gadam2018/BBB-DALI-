-make
cmd "make" in shell

-compile
gcc dali_app.c -o dali_app

-insert module in system and make it accessible by changing group and permission
sudo insmod dali_drv.ko
sudo chgrp dialout /dev/dali_drv
sudo chmod 660 /dev/dali_drv

