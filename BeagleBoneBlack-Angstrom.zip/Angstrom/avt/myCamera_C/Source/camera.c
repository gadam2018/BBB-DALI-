#include <stdio.h>
#include <string.h>

#include <SynchronousGrab.h>

int main()
{

VmbError_t err = VmbErrorSuccess;

char*           pCameraID   = NULL;         // The ID of the camera to use
const char*     pFileName   = NULL;         // The filename for the bitmap to save

pCameraID   = "DEV_000F31024586";
pFileName = "SGrab.bmp";

printf( "/// AVT Vimba API Synchronous Grab of an image ///\n" );

err = SynchronousGrab( pCameraID, pFileName );

printf( "/// AVT Vimba API Finished ///\n" );

return err;
}
