#include <string>
#include <cstring>
#include <iostream>

#include "ApiController.h"
#include "Bitmap.h"

unsigned char StartsWith(const char *pString, const char *pStart)
{
    if(NULL == pString)
    {
        return 0;
    }
    if(NULL == pStart)
    {
        return 0;
    }

    if(std::strlen(pString) < std::strlen(pStart))
    {
        return 0;
    }

    if(std::memcmp(pString, pStart, std::strlen(pStart)) != 0)
    {
        return 0;
    }

    return 1;
}




int main( int argc, char* argv[] )
{
    VmbErrorType    err         = VmbErrorSuccess;

    char *          pCameraID   = NULL;             // The ID of the camera to use
    const char *    pFileName   = NULL;             // The filename for the bitmap to save
    const char *    pFormatName   = NULL;           // The pixels format name for the image to capture
    const char *    pGainRaw = NULL;
    const char *    pExposureTime = NULL;
    const char *    pExposureAutoTarget = NULL;
    const char *    pBinningHorizontal = NULL;
    const char *    pBinningVertical = NULL;
    bool            bPrintHelp  = false;            // Output help?
    int             i;                              // Counter for some iteration
    char *          pParameter;                     // The command line parameter


//pCameraID   = "DEV_000F31024586";
pFileName = "SGrab.bmp";


    std::cout<<"//////////////////////////////////////////////\n";
    std::cout<<"/// AVT Vimba API Synchronous Grab Example ///\n";
    std::cout<<"//////////////////////////////////////////////\n\n";

    //////////////////////
    //Parse command line//
    //////////////////////

    for( i = 1; i < argc; ++i )
    {
        pParameter = argv[i];
        if( 0 > std::strlen( pParameter ))
        {
            err = VmbErrorBadParameter;
            break;
        }

        if( '-' == pParameter[0] )
        {
            if( StartsWith( pParameter, "-format:" ))
            {
                if( NULL != pFormatName )
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                pFormatName = pParameter + 8;
                if( 0 >= std::strlen( pFormatName ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }
            }

	     else if( StartsWith( pParameter, "-gain:" ))
             {
                if( NULL != pGainRaw )
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                pGainRaw = pParameter + 6;
                if( 0 >= std::strlen( pGainRaw ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }
            }

	     else if( StartsWith( pParameter, "-speed:" ))
             {
                if( NULL != pExposureTime )
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                pExposureTime = pParameter + 7;
                if( 0 >= std::strlen( pExposureTime ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }
            }

	    else if( StartsWith( pParameter, "-expauto:" ))
             {
                if( NULL != pExposureAutoTarget )
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                pExposureAutoTarget = pParameter + 9;
                if( 0 >= std::strlen( pExposureAutoTarget ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }
            }

	     else if( StartsWith( pParameter, "-binh:" ))
             {
                if( NULL != pBinningHorizontal )
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                pBinningHorizontal = pParameter + 6;
                if( 0 >= std::strlen( pBinningHorizontal ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }
            }

	     else if( StartsWith( pParameter, "-binv:" ))
             {
                if( NULL != pBinningVertical )
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                pBinningVertical = pParameter + 6;
                if( 0 >= std::strlen( pBinningVertical ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }
            }

            else if( 0 == std::strcmp( pParameter, "-h" ))
            {
                if(     ( NULL != pCameraID )
                    ||  ( NULL != pFormatName )
                    ||  ( NULL != pGainRaw )
                    ||  ( NULL != pExposureTime ) 
                    ||  ( NULL != pExposureAutoTarget)
                    ||  ( NULL != pBinningHorizontal)
                    ||  ( NULL != pBinningVertical)
                    ||  ( bPrintHelp ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                bPrintHelp = true;
            }
            else
            {
                err = VmbErrorBadParameter;
                break;
            }
        }
        else
        {
            if( NULL != pCameraID )
            {
                err = VmbErrorBadParameter;
                break;
            }

            pCameraID = pParameter;
        }
    }

    //Write out an error if we could not parse the command line
    if ( VmbErrorBadParameter == err )
    {
        std::cout<<"Invalid parameters!\n\n";
        bPrintHelp = true;
    }

    //Print out help and end program
    if ( bPrintHelp )
    {
        std::cout<<"Usage: SynchronousGrab [CameraID] [-h] [-format:FormatName] [-gain:GainRaw] [-speed:ExposureTimeAbs] [-expauto:ExposureAutoTarget] [-binh:BinningHorizontal] [-binv:BinningVertical]\n";
        std::cout<<"Parameters:   CameraID    ID of the camera to use (using first camera if not specified)\n";
        std::cout<<"              -h          Print out help\n";
        std::cout<<"              -format:FormatName Pixel Format name e.g. Mono8, RGB8Packed, BayerRG8, etc.\n";
        std::cout<<"              -gain:GainRaw value e.g. 1\n";
        std::cout<<"              -speed:ExposureTimeAbs value e.g. 15000\n";
        std::cout<<"              -expauto:ExposureAutoTarget value e.g. 50\n";
        std::cout<<"              -binh:BinningHorizontal value e.g. 1\n";
        std::cout<<"              -binv:BinningVertical value e.g. 1\n";
        std::cout<<"               (default \"SGrab.bmp/.dat\" if not specified)\n";
    }
    else
    {
        if ( NULL == pFormatName )
        {
            pFormatName = "VmbPixelFormatMono8";
        }

	if ( NULL == pGainRaw )
        {
            pGainRaw = "1";
        }
	if ( NULL == pExposureTime )
        {
            pExposureTime = "15000";
        }
	if ( NULL == pExposureAutoTarget )
        {
            pExposureAutoTarget = "50";
        }
	if ( NULL == pBinningHorizontal )
        {
            pBinningHorizontal = "1";
        }
	if ( NULL == pBinningVertical )
        {
            pBinningVertical = "1";
        }

	std::cout<<"/// AVT Vimba API Synchronous Grab of an image ///\n";


        AVT::VmbAPI::Examples::ApiController apiController;
        
        std::cout<<"Vimba Version V"<<apiController.GetVersion()<<"\n";

        err = apiController.StartUp();
        if ( VmbErrorSuccess == err )
        {

            std::string strCameraID;
            if(NULL == pCameraID)
            {
                AVT::VmbAPI::CameraPtrVector cameras = apiController.GetCameraList();
                if(cameras.size() <= 0)
                {
                    err = VmbErrorNotFound;
                }
                else
                {
                    err = cameras[0]->GetID(strCameraID);
                }
            }
            else
            {
                strCameraID = pCameraID;
            }
            
            if ( VmbErrorSuccess == err )
            {
                std::cout<<"Camera ID:"<< strCameraID.c_str()<<"\n\n";


		//std::cout<<"avtGCcapture PixelFormatName is:"<<pFormatName<<"\n";
	       


                AVT::VmbAPI::FramePtr pFrame;
		    
                   // VmbPixelFormatType ePixelFormat2;
		   // pFrame->GetPixelFormat( ePixelFormat2 );

                   // std::cout<<"0avtGCcapture 0x"<<std::hex<<ePixelFormat2<<std::dec <<"\n";
		   // std::cout<<"0avtGCcapture PixelFormat:"<<ePixelFormat2<<"\n";


	//std::string strpFormatName;

	// DES PROTA TO ARXEIO ApiController.cpp META TIN parakato KLISI TIS AcquireSingleImage
                err = apiController.AcquireSingleImage( strCameraID, pFrame, pFormatName, pGainRaw, pExposureTime, pExposureAutoTarget, pBinningHorizontal, pBinningVertical ); // CALLS FUNCTION to acquire image
	// TO ARXEIO EKEINO kanei SET to PIXELFORMAT!!!

                if ( VmbErrorSuccess == err )
                {
                    VmbPixelFormatType ePixelFormat = VmbPixelFormatMono8;
                    err = pFrame->GetPixelFormat( ePixelFormat );

                   // std::cout<<"avtGCcapture 0x"<<std::hex<<ePixelFormat<<std::dec <<"\n";
		    //std::cout<<"avtGCcapture PixelFormat:"<<ePixelFormat<<"\n";


       	// pixel format. only support Mono and BGR in this example.
	// DES PROTA TO ARXEIO ApiController.cpp META TIN PARAPANI KLISI TIS AcquireSingleImage
                    if ( VmbErrorSuccess == err )
                    //{
                        //if(     ( VmbPixelFormatMono8 != ePixelFormat )
                        //    &&  ( VmbPixelFormatRgb8 != ePixelFormat ))

                        //{
                            //err = VmbErrorInvalidValue;
                        //}
                        //else
                        {
                            VmbUint32_t nImageSize = 0; 
                            err = pFrame->GetImageSize( nImageSize );
                            if ( VmbErrorSuccess == err )
                            {
                                VmbUint32_t nWidth = 0;
                                err = pFrame->GetWidth( nWidth );
                                if ( VmbErrorSuccess == err )
                                {
                                    VmbUint32_t nHeight = 0;
                                    err = pFrame->GetHeight( nHeight );
                                    if ( VmbErrorSuccess == err )

                                    {
                                        VmbUchar_t *pImage = NULL;
                                        err = pFrame->GetImage( pImage );

                                        if ( VmbErrorSuccess == err )
                                        {
                                            AVTBitmap bitmap;

                                            if( VmbPixelFormatRgb8 == ePixelFormat ) // EDO APLOS KANEI SET TO COLORCODE analoga me to PIXELFORMAT
						{
						//std::cout<<"1. Color code is set to RGB24\n";
                                                bitmap.colorCode = ColorCodeRGB24;
                                            }
                                       
                                            else
						if (( VmbPixelFormatMono8 == ePixelFormat )
						   || (strcmp(pFormatName,"YUV411Packed")==0)
						   || (strcmp(pFormatName,"YUV422Packed")==0)
						   || (strcmp(pFormatName,"YUV444Packed")==0))
                                            	{
                                               //  std::cout<<"2. Color code is set to Mono8\n";
						bitmap.colorCode = ColorCodeMono8;
                                            	}
						else
						{
					        // std::cout<<"3. Color code is set to RGB24\n";
						bitmap.colorCode = ColorCodeRGB24;
						}

                                            bitmap.bufferSize = nImageSize;
                                            bitmap.width = nWidth;
                                            bitmap.height = nHeight;

                                            // Create the bitmap
                                            if ( 0 == AVTCreateBitmap( &bitmap, pImage ))
                                            {
                                                 std::cout<<"Could not create bitmap.\n";
                                                err = VmbErrorResources;
                                            }
                                            else
                                            {
                                                // Save the bitmap
                                                if ( 0 == AVTWriteBitmapToFile( &bitmap, pFileName ))
                                                {
                                                    std::cout<<"Could not write bitmap to file.\n";
                                                    err = VmbErrorOther;
                                                }
                                                else
                                                {
                                                    std::cout<<"Bitmap successfully written to file \""<<pFileName<<"\"\n" ;
                                                    // Release the bitmap's buffer
                                                    if ( 0 == AVTReleaseBitmap( &bitmap ))
                                                    {
                                                        std::cout<<"Could not release the bitmap.\n";
                                                        err = VmbErrorInternalFault;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
           //}

            apiController.ShutDown();

        }

        if ( VmbErrorSuccess != err )
        {
            std::string strError = apiController.ErrorCodeToMessage( err );
            std::cout<<"\nAn error occurred: "<<strError.c_str()<<"\n";
        }

 std::cout<<"/// AVT Vimba API Finished ///\n";
}

return err;
}
