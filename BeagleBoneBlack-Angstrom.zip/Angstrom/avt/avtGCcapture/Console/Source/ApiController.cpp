/*=============================================================================
  Copyright (C) 2013 Allied Vision Technologies.  All Rights Reserved.

  Redistribution of this file, in original or modified form, without
  prior written consent of Allied Vision Technologies is prohibited.

-------------------------------------------------------------------------------

  File:        ApiController.cpp

  Description: Implementation file for the ApiController helper class that
               demonstrates how to implement a synchronous single image
               acquisition with VimbaCPP.

-------------------------------------------------------------------------------

  THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR IMPLIED
  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF TITLE,
  NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR  PURPOSE ARE
  DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
  AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
  TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

=============================================================================*/

#include <sstream>
#include <iostream>
#include <string>

#include "ApiController.h"
#include "Common/StreamSystemInfo.h"
#include "Common/ErrorCodeToMessage.h"

namespace AVT {
namespace VmbAPI {
namespace Examples {

enum { NUM_FRAMES = 3, };

ApiController::ApiController()
    // Get a reference to the Vimba singleton
    : m_system ( VimbaSystem::GetInstance() )
{
}

ApiController::~ApiController()
{
}


VmbErrorType ApiController::StartUp()
{
    return m_system.Startup();
}

void ApiController::ShutDown()
{
    // Release Vimba
    m_system.Shutdown();
}

VmbErrorType ApiController::AcquireSingleImage( const std::string &rStrCameraID, FramePtr &rpFrame , const char * rpFormatName, const char * rpGainRaw, const char * rpExposureTime, const char * rpExposureAutoTarget, const char * rpBinningHorizontal, const char * rpBinningVertical) // const std::string &rpFormatName)
{
    // Open the desired camera by its ID
    VmbErrorType res = m_system.OpenCameraByID( rStrCameraID.c_str(), VmbAccessModeFull, m_pCamera);
    if ( VmbErrorSuccess == res )
    {
        // Set the GeV packet size to the highest possible value
        // (In this example we do not test whether this cam actually is a GigE cam)
        FeaturePtr pCommandFeature;
        if ( VmbErrorSuccess == m_pCamera->GetFeatureByName( "GVSPAdjustPacketSize", pCommandFeature ))
        {
            if ( VmbErrorSuccess == pCommandFeature->RunCommand() )
            {
                bool bIsCommandDone = false;
                do
                {
                    if ( VmbErrorSuccess != pCommandFeature->IsCommandDone( bIsCommandDone ))
                    {
                        break;
                    }
                } while ( false == bIsCommandDone );
            }
        }
        FeaturePtr pFormatFeature;
        


	// Set pixel format. For the sake of simplicity we only support Mono and BGR in this example.
        res = m_pCamera->GetFeatureByName( "PixelFormat", pFormatFeature );
	//std::string format;
	//res = pFormatFeature->GetValue( format);
	//std::cout<<"Format is: "<<format <<"\n";


        if ( VmbErrorSuccess == res )
        {
            // Try to set the Pixel Format Name  given in rpFormatName   
           res = pFormatFeature->SetValue( rpFormatName );   
	std::string format;
	res = pFormatFeature->GetValue( format);
	//std::cout<<"Format is: "<<format <<"\n";
	std::cout<<"PixelFormatName is set to: "<<format<<"\n"; 
	//std::cout<<"Now PixelFormatName is set to: "<<rpFormatName<<"\n"; 

      //res = pFormatFeature->SetValue( VmbPixelFormatRgb8 );
            if ( VmbErrorSuccess != res )
            {
                // Fall back to Mono
                res = pFormatFeature->SetValue( VmbPixelFormatMono8 );
            }

	// GETTING THE VALUES OF GainAuto and ExposureAuto & ExposureAutoTarget FEATURES
        FeaturePtr pGainAutoFeature, pExposureAutoFeature;//, pExposureAutoTargetFeature;
	std::string gainauto, exposureauto;
	//double exposureautotarget; //kanonika prepei na dilothei int alla gia kapoio logo den douleuei meta h GetValue
	res = m_pCamera->GetFeatureByName( "GainAuto", pGainAutoFeature );
	res = m_pCamera->GetFeatureByName( "ExposureAuto", pExposureAutoFeature );
	//res = m_pCamera->GetFeatureByName( "ExposureAutoTarget", pExposureAutoTargetFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pGainAutoFeature->GetValue( gainauto);  //std::cout<<"GainAuto is: "<<gainauto<<"\n";
		res = pExposureAutoFeature->GetValue( exposureauto); //std::cout<<"ExposureAuto is: "<<exposureauto<<"\n";
		//res = pExposureAutoTargetFeature->GetValue( exposureautotarget); std::cout<<"ExposureAutoTarget is: "<<exposureautotarget<<"\n";
	    }
	
	// SETTING THE GainAuto and ExposureAuto & ExposureAutoTarget FEATURES
        res = pGainAutoFeature->SetValue( "Off" );   
	res = pGainAutoFeature->GetValue( gainauto); 	std::cout<<"GainAuto is set to: "<<gainauto<<"\n";

	res = pExposureAutoFeature->SetValue( "Off" );   
	res = pExposureAutoFeature->GetValue( exposureauto); 	std::cout<<"ExposureAuto is set to: "<<exposureauto<<"\n";

	//res = pExposureAutoTargetFeature->SetValue(0);   
	//res = pExposureAutoTargetFeature->GetValue( exposureautotarget); std::cout<<"Now ExposureAutoTarget is set to: "<<exposureautotarget<<"\n";

	// DEN VRISKEI TO GAIN FEATURE
    /*   FeaturePtr pGainFeature;
	double gain;
	res = m_pCamera->GetFeatureByName( "Gain", pGainFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pGainFeature->GetValue( gain);
		std::cout<<"Gain is: "<<gain<<"\n";
	    } 
	*/


 	FeaturePtr pGainRawFeature;
        res = m_pCamera->GetFeatureByName( "GainRaw", pGainRawFeature );
	std::string temp4 = rpGainRaw;
	VmbInt64_t temp5;
	std::istringstream convert2(temp4);
	convert2 >>temp5;
	VmbInt64_t gainraw; //, val0=2;
	res = pGainRawFeature->SetValue(temp5);	if ( VmbErrorSuccess != res )  {std::cout<<"Fail to set GainRaw value\n";}
	res = pGainRawFeature->GetValue(gainraw); //if ( VmbErrorSuccess != res )  {std::cout<<"Fail to get GainRaw value\n";}
	std::cout<<"GainRaw is set to: "<<gainraw <<"\n";


       FeaturePtr pExposureTimeAbsFeature;
	double exposuretimeabs;
	//double rexposuretimeabs = std::stol(rpExposureTime,0,0);
	//int test = atoi(rpExposureTime.c_str());

	//std::cout<<"ExposureTimeAbs will be set to: "<<rpExposureTime<<"\n";

	double exptime;
	std::string temp2 = rpExposureTime;
	double temp3;
	std::istringstream convert(temp2);
	convert >>temp3;

	res = m_pCamera->GetFeatureByName( "ExposureTimeAbs", pExposureTimeAbsFeature );
 	if ( VmbErrorSuccess == res )
            {
		//res = pExposureTimeAbsFeature->GetValue( exposuretimeabs);
		//std::cout<<"ExposureTimeAbs is: "<<exposuretimeabs<<"\n";
		//res = pExposureTimeAbsFeature->SetValue( rpExposureTime);
		res = pExposureTimeAbsFeature->SetValue( temp3);
		res = pExposureTimeAbsFeature->GetValue( exptime);
		std::cout<<"ExposureTimeAbs is set to: "<<exptime<<"\n";
		//std::cout<<"Now ExposureTimeAbs is set to: "<<rpExposureTime<<"\n";
	    } 


	FeaturePtr pExposureAutoTargetFeature;
        res = m_pCamera->GetFeatureByName( "ExposureAutoTarget", pExposureAutoTargetFeature );
	std::string temp6 = rpExposureAutoTarget;
	VmbInt64_t temp7;
	std::istringstream convert3(temp6);
	convert3 >>temp7;
	VmbInt64_t exposureautotarget; //, val2=2;
	res = pExposureAutoTargetFeature->SetValue(temp7);	if ( VmbErrorSuccess != res )  {std::cout<<"Fail to set ExposureAutoTarget value\n";}
	res = pExposureAutoTargetFeature->GetValue(exposureautotarget); //if(VmbErrorSuccess != res ){std::cout<<"Fail to get ExposureAutoTarget value\n";}
	std::cout<<"ExposureAutoTarget is set to: "<<exposureautotarget <<"\n";


	FeaturePtr pBinningHFeature;
        res = m_pCamera->GetFeatureByName( "BinningHorizontal", pBinningHFeature );
	std::string temp8 = rpBinningHorizontal;
	VmbInt64_t temp9;
	std::istringstream convert4(temp8);
	convert4 >>temp9;
	VmbInt64_t binningh; //, val2=2;
	res = pBinningHFeature->SetValue(temp9);	if ( VmbErrorSuccess != res )  {std::cout<<"Fail to set BinningHorizontal value\n";}
	res = pBinningHFeature->GetValue(binningh); //if ( VmbErrorSuccess != res )  {std::cout<<"Fail to get BinningHorizontal value\n";}
	std::cout<<"BinningHorizontal is set to: "<<binningh <<"\n";

	FeaturePtr pBinningVFeature;
        res = m_pCamera->GetFeatureByName( "BinningVertical", pBinningVFeature );
	std::string temp10 = rpBinningVertical;
	VmbInt64_t temp11;
	std::istringstream convert5(temp10);
	convert5 >>temp11;
	VmbInt64_t binningv; //, val3=2;
	res = pBinningVFeature->SetValue(temp11);	if ( VmbErrorSuccess != res )  {std::cout<<"Fail to set BinningVertical value\n";}
	res = pBinningVFeature->GetValue(binningv); //if ( VmbErrorSuccess != res )  {std::cout<<"Fail to get BinningVertical value\n";}
	std::cout<<"BinningVertical is set to: "<<binningv <<"\n";



            if ( VmbErrorSuccess == res )
            {
                // Acquire
                res = m_pCamera->AcquireSingleImage( rpFrame, 5000 );
            }
      
	//res = pGainAutoFeature->GetValue( gainauto);	std::cout<<"GainAuto is: "<<gainauto<<"\n";
	//res = pExposureAutoFeature->GetValue( exposureauto); 	std::cout<<"ExposureAuto is: "<<exposureauto<<"\n";
  	}
        m_pCamera->Close();
    }

    return res;
}

CameraPtrVector ApiController::GetCameraList()
{
    CameraPtrVector cameras;
    // Get all known cameras
    if ( VmbErrorSuccess == m_system.GetCameras( cameras ))
    {
        // And return them
        return cameras;
    }
    return CameraPtrVector();
}
// Translates Vimba error codes to readable error messages
std::string ApiController::ErrorCodeToMessage( VmbErrorType eErr ) const
{
    return AVT::VmbAPI::Examples::ErrorCodeToMessage( eErr );
}
// Translates Vimba error codes to readable error messages

std::string ApiController::GetVersion() const
{
    std::ostringstream os;
    os<<m_system;
    return os.str();
}


}}} // namespace AVT::VmbAPI::Examples
