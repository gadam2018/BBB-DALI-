/*=============================================================================
  Copyright (C) 2013 Allied Vision Technologies.  All Rights Reserved.

  Redistribution of this file, in original or modified form, without
  prior written consent of Allied Vision Technologies is prohibited.

-------------------------------------------------------------------------------

  File:        ApiController.cpp

  Description: Implementation file for the ApiController helper class that
               demonstrates how to implement a synchronous single image
               acquisition with VimbaCPP.

=============================================================================*/

#include <sstream>
#include <iostream>

#include "ApiController.h"
#include "Common/StreamSystemInfo.h"
#include "Common/ErrorCodeToMessage.h"

namespace AVT {
namespace VmbAPI {
namespace Examples {

enum { NUM_FRAMES = 3, };

ApiController::ApiController()
    // Get a reference to the Vimba singleton
    : m_system ( VimbaSystem::GetInstance() )
{
}

ApiController::~ApiController()
{
}


VmbErrorType ApiController::StartUp()
{
    return m_system.Startup();
}

void ApiController::ShutDown()
{
    // Release Vimba
    m_system.Shutdown();
}


VmbErrorType ApiController::AcquireInfo( const std::string &rStrCameraID, FramePtr &rpFrame)
{
    	//std::cout<<"ApiController initial format is:"<<format<<"\n";
	// Open the desired camera by its ID
    VmbErrorType res = m_system.OpenCameraByID( rStrCameraID.c_str(), VmbAccessModeFull, m_pCamera);
    if ( VmbErrorSuccess == res )
    {
	FeaturePtr pFormatFeature;
 	res = m_pCamera->GetFeatureByName( "PixelFormat", pFormatFeature );

            if ( VmbErrorSuccess == res )
            {	
 		
		//std::string ePixelFormat;
	        //res = pFormatFeature->GetValue( ePixelFormat);

	        res = pFormatFeature->GetValue( format);
		//std::cout<<"Format is: "<<format<<"\n";

		//VmbPixelFormatType ePixelFormat;
       		//res = rpFrame->GetPixelFormat( ePixelFormat );

		//std::cout<<"Format is: "<<ePixelFormat <<"\n";


	    }
	//std::cout<<"ApiController PixelFormatName is:"<<rpFormatName<<"\n";
             
 	res = m_pCamera->GetFeatureByName( "GainAuto", pFormatFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pFormatFeature->GetValue( gainauto);
		//std::cout<<"GainAuto is: "<<gainauto<<"\n";
	    }

	res = m_pCamera->GetFeatureByName( "ExposureAuto", pFormatFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pFormatFeature->GetValue( exposureauto);
		//std::cout<<"ExposureAuto is: "<<exposureauto<<"\n";
	    }

	res = m_pCamera->GetFeatureByName( "ExposureTimeAbs", pFormatFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pFormatFeature->GetValue( exposuretime);
		//std::cout<<"ExposureAuto is: "<<exposureauto<<"\n";
	    }

	//if(AVT::VmbAPI::IsReadable(Gain))
	//	std::cout<< "Readble"<<"\n";

/*	res = m_pCamera->GetFeatureByName( "Gain", pFormatFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pFormatFeature->GetValue( gain);
		std::cout<<"Gain is: "<<gain<<"\n";
	    }
*/

	res = m_pCamera->GetFeatureByName( "GainRaw", pFormatFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pFormatFeature->GetValue( gainraw);
		//std::cout<<"GainRaw is: "<<gainraw<<"\n";
	    }

	res = m_pCamera->GetFeatureByName( "ExposureAutoTarget", pFormatFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pFormatFeature->GetValue( exposureautotarget);
		//std::cout<<"ExposureAutoTarget is: "<<exposureautotarget<<"\n";
	    }

	res = m_pCamera->GetFeatureByName( "BinningHorizontal", pFormatFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pFormatFeature->GetValue( binningh);
		//std::cout<<"BinningHorizontal is: "<<binningh<<"\n";
	    }

	res = m_pCamera->GetFeatureByName( "BinningVertical", pFormatFeature );
 	if ( VmbErrorSuccess == res )
            {
		res = pFormatFeature->GetValue( binningv);
		//std::cout<<"BinningVertical is: "<<binningv<<"\n";
	    }

        m_pCamera->Close();
    }
    return res;
}


CameraPtrVector ApiController::GetCameraList()
{
    CameraPtrVector cameras;
    // Get all known cameras
    if ( VmbErrorSuccess == m_system.GetCameras( cameras ))
    {
        // And return them
        return cameras;
    }
    return CameraPtrVector();
}
// Translates Vimba error codes to readable error messages
std::string ApiController::ErrorCodeToMessage( VmbErrorType eErr ) const
{
    return AVT::VmbAPI::Examples::ErrorCodeToMessage( eErr );
}
// Translates Vimba error codes to readable error messages

std::string ApiController::GetVersion() const
{
    std::ostringstream os;
    os<<m_system;
    return os.str();
}


}}} // namespace AVT::VmbAPI::Examples
