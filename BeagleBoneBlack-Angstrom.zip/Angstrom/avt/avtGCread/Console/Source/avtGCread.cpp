#include <string>
#include <cstring>
#include <iostream>

#include "ApiController.h"

std::string format; // Declaration of the pixels format name as a GLOBAL (EXTERN) VARIABLE
std::string  gainauto,exposureauto;
double gain,exposuretime;
VmbInt64_t gainraw, exposureautotarget, binningh, binningv;

unsigned char StartsWith(const char *pString, const char *pStart)
{
    if(NULL == pString)
    {
        return 0;
    }
    if(NULL == pStart)
    {
        return 0;
    }

    if(std::strlen(pString) < std::strlen(pStart))
    {
        return 0;
    }

    if(std::memcmp(pString, pStart, std::strlen(pStart)) != 0)
    {
        return 0;
    }

    return 1;
}




int main( int argc, char* argv[] )
{
    VmbErrorType    err         = VmbErrorSuccess;

    char *          pCameraID   = NULL;             // The ID of the camera to use
    bool            bPrintHelp  = false;            // Output help?
    int             i;                              // Counter for some iteration
    char *          pParameter;                     // The command line parameter


//pCameraID   = "DEV_000F31024586";
//pFileName = "SGrab.bmp";


    std::cout<<"//////////////////////////////////////////////\n";
    std::cout<<"/// AVT Vimba API Getting Information      ///\n";
    std::cout<<"//////////////////////////////////////////////\n\n";

    //////////////////////
    //Parse command line//
    //////////////////////

    for( i = 1; i < argc; ++i )
    {
        pParameter = argv[i];
        if( 0 > std::strlen( pParameter ))
        {
            err = VmbErrorBadParameter;
            break;
        }

        if( '-' == pParameter[0] )
        {
            if( StartsWith( pParameter, "-format" ))
            {
                //if( NULL != pFormatName )
               // {
               //     err = VmbErrorBadParameter;
              //      break;
             //   }

               // pFormatName = pParameter + 8;
              //  if( 0 >= std::strlen( pFormatName ))
              //  {
             //       err = VmbErrorBadParameter;
              //      break;
               // }
            }
 	   else if( StartsWith( pParameter, "-speed" ))
             {
/*
                if( NULL != pExposureTime )
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                pExposureTime = pParameter + 7;
                if( 0 >= std::strlen( pExposureTime ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }
*/
            }
		else if( StartsWith( pParameter, "-gain" ) || StartsWith( pParameter, "-expauto" ) ||StartsWith( pParameter, "-binh" )||StartsWith( pParameter, "-binv" ))
             {
		;
            }
            else if( 0 == std::strcmp( pParameter, "-h" ))
            {
                if(     ( NULL != pCameraID )
                    ||  ( bPrintHelp ))
                {
                    err = VmbErrorBadParameter;
                    break;
                }

                bPrintHelp = true;
            }
            else
            {
                err = VmbErrorBadParameter;
                break;
            }
        }
        else
        {
            if( NULL != pCameraID )
            {
                err = VmbErrorBadParameter;
                break;
            }

            pCameraID = pParameter;
        }
    }

    //Write out an error if we could not parse the command line
    if ( VmbErrorBadParameter == err )
    {
        std::cout<<"Invalid parameters!\n\n";
        bPrintHelp = true;
    }

    //Print out help and end program
    if ( bPrintHelp )
    {
        std::cout<<"Usage: avtGCread [CameraID] [-h] [-format] [-speed] [-gain] [-expauto] [-binh] [-binv]\n";
        std::cout<<"Parameters:   CameraID    ID of the camera to use (using first camera if not specified)\n";
        std::cout<<"              -h          Print out help\n";
        std::cout<<"              -format     Get Pixel Format name\n";
        std::cout<<"              -speed      Get ExposureTimeAbs\n";
        std::cout<<"              -gain       Get GainRaw\n";
        std::cout<<"              -expauto    Get ExposureAutoTarget\n";
        std::cout<<"              -binh       Get BinningHorizontal\n";
        std::cout<<"              -binv       Get BinningVertical\n";
    }
    else
    {
  
        AVT::VmbAPI::Examples::ApiController apiController;
        
        std::cout<<"Vimba Version V"<<apiController.GetVersion()<<"\n";

        err = apiController.StartUp();
        if ( VmbErrorSuccess == err )
        {

            std::string strCameraID;
 	    std::string strCameraName;
 	    std::string strCameraModel;
	   // AVT::VmbAPI::FeaturePtr feature;
	   // VmbInt64_t width;
            if(NULL == pCameraID)
            {
                AVT::VmbAPI::CameraPtrVector cameras = apiController.GetCameraList();
                if(cameras.size() <= 0)
                {
                    err = VmbErrorNotFound;
                }
                else
                {
                    err = cameras[0]->GetID(strCameraID);
		    err = cameras[0]->GetName(strCameraName);
		    err = cameras[0]->GetModel(strCameraModel);
		  //  err = cameras[0]->GetFeatureByName("Width", feature);
		   // feature->GetValue(width);
                }
            }
            else
            {
                strCameraID = pCameraID;
            }
            
            if ( VmbErrorSuccess == err )
            {
                std::cout<<"Camera ID:"<< strCameraID.c_str()<<"\n";
                std::cout<<"Camera Name:"<< strCameraName.c_str()<<"\n"; // OR std::cout<<"Camera Name:"<< strCameraName<<"\n";
                std::cout<<"Camera Model:"<< strCameraModel.c_str()<<"\n";
		//std::cout <<width <<"\n";
	    }

                AVT::VmbAPI::FramePtr pFrame;

		err = apiController.AcquireInfo( strCameraID, pFrame);
    	
	   std::cout<<"Camera Format is: "<<format<<"\n";
	   std::cout<<"Camera GainAuto is: "<<gainauto<<"\n";
	   std::cout<<"Camera GainRaw is: "<<gainraw<<"\n";
	  // std::cout<<"Camera Gain is: "<<gain<<"\n";
	  std::cout<<"Camera ExposureAuto is: "<<exposureauto<<"\n";
	  std::cout<<"Camera ExposureTimeAbs is: "<<exposuretime<<"\n";
	  std::cout<<"Camera ExposureAutoTarget is: "<<exposureautotarget<<"\n";
	  std::cout<<"Camera BinningHorizontal is: "<<binningh<<"\n";
	  std::cout<<"Camera BinningVertical is: "<<binningv<<"\n";

            apiController.ShutDown();

        }  // kleinei tin if ( VmbErrorSuccess == err ) - diladi if started up successfully

        if ( VmbErrorSuccess != err )
        {
            std::string strError = apiController.ErrorCodeToMessage( err );
            std::cout<<"\nAn error occurred: "<<strError.c_str()<<"\n";
        }

 std::cout<<"/// AVT Vimba API Finished ///\n";
} // kleinei to else tou if ( bPrintHelp )

return err;
} // telos tis main()
