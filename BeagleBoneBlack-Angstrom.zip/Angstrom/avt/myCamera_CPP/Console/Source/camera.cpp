#include <string>
#include <cstring>
#include <iostream>

#include "ApiController.h"
#include "Bitmap.h"

#include "CImg.h"
//using namespace cimg_library;

int main( int argc, char* argv[] )
{

VmbErrorType    err         = VmbErrorSuccess;

char*           pCameraID   = NULL;         // The ID of the camera to use
const char*     pFileName   = NULL;         // The filename for the bitmap to save
const char* 	output =NULL;

pCameraID   = "DEV_000F31024586";
pFileName = "SGrab.bmp";
output ="ThreshGrab.bmp";

std::cout<<"/// AVT Vimba API Synchronous Grab of an image ///\n";


        AVT::VmbAPI::Examples::ApiController apiController;
        
        std::cout<<"Vimba Version V"<<apiController.GetVersion()<<"\n";

        err = apiController.StartUp();
        if ( VmbErrorSuccess == err )
        {

            std::string strCameraID;
            if(NULL == pCameraID)
            {
                AVT::VmbAPI::CameraPtrVector cameras = apiController.GetCameraList();
                if(cameras.size() <= 0)
                {
                    err = VmbErrorNotFound;
                }
                else
                {
                    err = cameras[0]->GetID(strCameraID);
                }
            }
            else
            {
                strCameraID = pCameraID;
            }
            
            if ( VmbErrorSuccess == err )
            {
                std::cout<<"Camera ID:"<< strCameraID.c_str()<<"\n\n";

                AVT::VmbAPI::FramePtr pFrame;
                err = apiController.AcquireSingleImage( strCameraID, pFrame );
                if ( VmbErrorSuccess == err )
                {
                    VmbPixelFormatType ePixelFormat = VmbPixelFormatMono8;
                    err = pFrame->GetPixelFormat( ePixelFormat );
                    if ( VmbErrorSuccess == err )
                    {
                        if(     ( VmbPixelFormatMono8 != ePixelFormat )
                            &&  ( VmbPixelFormatRgb8 != ePixelFormat ))

                        {
                            err = VmbErrorInvalidValue;
                        }
                        else
                        {
                            VmbUint32_t nImageSize = 0; 
                            err = pFrame->GetImageSize( nImageSize );
                            if ( VmbErrorSuccess == err )
                            {
                                VmbUint32_t nWidth = 0;
                                err = pFrame->GetWidth( nWidth );
                                if ( VmbErrorSuccess == err )
                                {
                                    VmbUint32_t nHeight = 0;
                                    err = pFrame->GetHeight( nHeight );
                                    if ( VmbErrorSuccess == err )

                                    {
                                        VmbUchar_t *pImage = NULL;
                                        err = pFrame->GetImage( pImage );

                                        if ( VmbErrorSuccess == err )
                                        {
                                            AVTBitmap bitmap;

                                            if( VmbPixelFormatRgb8 == ePixelFormat )
                                            {
                                                bitmap.colorCode = ColorCodeRGB24;

                                            }
                                            else
                                            {
                                                bitmap.colorCode = ColorCodeMono8;
                                            }

                                            bitmap.bufferSize = nImageSize;
                                            bitmap.width = nWidth;
                                            bitmap.height = nHeight;

                                            // Create the bitmap
                                            if ( 0 == AVTCreateBitmap( &bitmap, pImage ))
                                            {
                                                 std::cout<<"Could not create bitmap.\n";
                                                err = VmbErrorResources;
                                            }
                                            else
                                            {
                                                // Save the bitmap
                                                if ( 0 == AVTWriteBitmapToFile( &bitmap, pFileName ))
                                                {
                                                    std::cout<<"Could not write bitmap to file.\n";
                                                    err = VmbErrorOther;
                                                }
                                                else
                                                {
                                                    std::cout<<"Bitmap successfully written to file \""<<pFileName<<"\"\n" ;
                                                    // Release the bitmap's buffer
                                                    if ( 0 == AVTReleaseBitmap( &bitmap ))
                                                    {
                                                        std::cout<<"Could not release the bitmap.\n";
                                                        err = VmbErrorInternalFault;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            apiController.ShutDown();

        }

        if ( VmbErrorSuccess != err )
        {
            std::string strError = apiController.ErrorCodeToMessage( err );
            std::cout<<"\nAn error occurred: "<<strError.c_str()<<"\n";
        }

 std::cout<<"/// AVT Vimba API Finished ///\n";


cimg_library::CImg<unsigned char> image(pFileName);
cimg_library::CImgDisplay main_disp(image,"Click on image to threshold it");
while (!main_disp.is_closed()) {
    main_disp.wait();
    if (main_disp.button() && main_disp.mouse_y()>=0) 
    {
     cimg_library::CImgDisplay main_disp2(image.get_threshold(128).normalize(0,255),"Click on image to exit");
     image=image.get_threshold(128).normalize(0,255);
     image.save(output);
     while (!main_disp2.is_closed()) {
            main_disp2.wait();
            if (main_disp2.button() && main_disp2.mouse_y()>=0) 
            {
             exit(0);
            }
          }
     }
}

return err;
}
